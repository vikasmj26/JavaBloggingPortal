package com.entity.blog;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Admin {
	@Id
	private int adminid;
	private String name;
	private String pass;

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(int adminid, String name, String pass) {
		super();
		this.adminid = adminid;
		this.name = name;
		this.pass = pass;
	}

	public int getAdminid() {
		return adminid;
	}

	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	@Override
	public String toString() {
		return "Admin [adminid=" + adminid + ", name=" + name + ", pass=" + pass + "]";
	}

}
